var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/select-payment-method':
                'SantaWeb_DPM/js/action/select-payment-method'
        }
    }
}; 
